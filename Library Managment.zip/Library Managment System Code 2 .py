import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime, timedelta

def setup_database():
    conn = sqlite3.connect('library_gui_v4.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS books (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        author TEXT NOT NULL,
                        total_copies INTEGER NOT NULL,
                        available_copies INTEGER NOT NULL,
                        status TEXT DEFAULT 'Available',
                        issue_date TEXT,
                        due_date TEXT)''')
    conn.commit()
    conn.close()

class LibraryGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Library Management System")
        self.root.geometry("1150x650")
        self.root.configure(bg="#f5f3ee")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#f5f3ee")
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"), background="#1a237e", foreground="white")
        
        setup_database()
        self.selected_book_id = None

        self.create_widgets()
        self.refresh_table()

    def create_widgets(self):
        header_frame = tk.Frame(self.root, bg="#1a237e", height=60)
        header_frame.pack(fill="x", side="top")
        header_frame.pack_propagate(False)
        tk.Label(header_frame, text="📚 Library Management System", font=("Arial", 18, "bold"), bg="#1a237e", fg="white").pack(side="left", padx=20, pady=15)

        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill="both", expand=True)

        left_panel = ttk.Frame(main_frame, width=250)
        left_panel.pack(side="left", fill="y", padx=(0, 20))

        add_card = tk.Frame(left_panel, bg="#ffffff", bd=1, relief="solid", padx=15, pady=15)
        add_card.pack(fill="x", pady=(0, 20))
        tk.Label(add_card, text="➕ Add New Book", font=("Arial", 12, "bold"), bg="#ffffff", fg="#1a237e").pack(anchor="w", pady=(0, 10))
        
        tk.Label(add_card, text="TITLE", font=("Arial", 8, "bold"), bg="#ffffff", fg="#78716c").pack(anchor="w")
        self.title_entry = ttk.Entry(add_card)
        self.title_entry.pack(fill="x", pady=(0, 10))

        tk.Label(add_card, text="AUTHOR", font=("Arial", 8, "bold"), bg="#ffffff", fg="#78716c").pack(anchor="w")
        self.author_entry = ttk.Entry(add_card)
        self.author_entry.pack(fill="x", pady=(0, 10))

        tk.Label(add_card, text="TOTAL COPIES", font=("Arial", 8, "bold"), bg="#ffffff", fg="#78716c").pack(anchor="w")
        self.copies_entry = ttk.Entry(add_card)
        self.copies_entry.insert(0, "1")
        self.copies_entry.pack(fill="x", pady=(0, 15))

        tk.Button(add_card, text="➕ Add Book", bg="#2e7d32", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.add_book).pack(fill="x", ipady=5)

        action_card = tk.Frame(left_panel, bg="#ffffff", bd=1, relief="solid", padx=15, pady=15)
        action_card.pack(fill="x")
        tk.Label(action_card, text="⚙️ Book Actions", font=("Arial", 12, "bold"), bg="#ffffff", fg="#1a237e").pack(anchor="w", pady=(0, 10))

        tk.Button(action_card, text="📤 Issue Book", bg="#e65100", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.issue_book).pack(fill="x", pady=5, ipady=3)
        tk.Button(action_card, text="📥 Return Book", bg="#1565c0", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.return_book).pack(fill="x", pady=5, ipady=3)
        tk.Frame(action_card, height=1, bg="#e2ddd6").pack(fill="x", pady=10)
        tk.Button(action_card, text="🗑️ Delete Book", bg="#b71c1c", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.delete_book).pack(fill="x", pady=5, ipady=3)

        right_panel = ttk.Frame(main_frame)
        right_panel.pack(side="left", fill="both", expand=True)

        table_frame = tk.Frame(right_panel, bg="#ffffff", bd=1, relief="solid")
        table_frame.pack(fill="both", expand=True)
        
        columns = ("index", "id", "title", "author", "total_copies", "avail_copies", "status", "issue_date", "due_date")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        
        self.tree.heading("index", text="#")
        self.tree.heading("id", text="ID")
        self.tree.heading("title", text="Title")
        self.tree.heading("author", text="Author")
        self.tree.heading("total_copies", text="Total")
        self.tree.heading("avail_copies", text="Avail")
        self.tree.heading("status", text="Status")
        self.tree.heading("issue_date", text="Last Issued")
        self.tree.heading("due_date", text="Due Date")
        
        self.tree.column("index", width=30, anchor="center")
        self.tree.column("id", width=40, anchor="center")
        self.tree.column("title", width=180)
        self.tree.column("author", width=130)
        self.tree.column("total_copies", width=50, anchor="center")
        self.tree.column("avail_copies", width=50, anchor="center")
        self.tree.column("status", width=90, anchor="center")
        self.tree.column("issue_date", width=90, anchor="center")
        self.tree.column("due_date", width=90, anchor="center")
        
        self.tree.pack(fill="both", expand=True, padx=1, pady=1)
        self.tree.bind("<ButtonRelease-1>", self.select_row)

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
            
        conn = sqlite3.connect('library_gui_v4.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, author, total_copies, available_copies, status, IFNULL(issue_date, '-'), IFNULL(due_date, '-') FROM books")
            
        rows = cursor.fetchall()
        for index, row in enumerate(rows, start=1):
            display_row = (index,) + row
            self.tree.insert("", "end", values=display_row)
            
        conn.close()
        self.selected_book_id = None

    def select_row(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item, 'values')
            self.selected_book_id = values[1]

    def add_book(self):
        title = self.title_entry.get().strip()
        author = self.author_entry.get().strip()
        copies_input = self.copies_entry.get().strip()
        
        if not title or not author:
            messagebox.showwarning("Input Error", "Please fill in both Title and Author.")
            return
            
        if not copies_input.isdigit() or int(copies_input) < 1:
            copies = 1
        else:
            copies = int(copies_input)
            
        conn = sqlite3.connect('library_gui_v4.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO books (title, author, total_copies, available_copies, status) VALUES (?, ?, ?, ?, 'Available')", (title, author, copies, copies))
        conn.commit()
        conn.close()
        
        self.title_entry.delete(0, tk.END)
        self.author_entry.delete(0, tk.END)
        self.copies_entry.delete(0, tk.END)
        self.copies_entry.insert(0, "1")
        self.refresh_table()

    def issue_book(self):
        if not self.selected_book_id:
            messagebox.showwarning("Selection Error", "Please select a book.")
            return

        conn = sqlite3.connect('library_gui_v4.db')
        cursor = conn.cursor()
        cursor.execute("SELECT available_copies FROM books WHERE id=?", (self.selected_book_id,))
        available_copies = cursor.fetchone()[0]

        if available_copies <= 0:
            messagebox.showinfo("Notice", "This book is currently out of stock.")
            conn.close()
            return

        issue_qty = simpledialog.askinteger("Issue Book", f"Available Copies: {available_copies}\n\nHow many copies do you want to issue?", minvalue=1, maxvalue=available_copies)
        
        if issue_qty:
            new_avail = available_copies - issue_qty
            status = 'Available' if new_avail > 0 else 'Out of Stock'
            
            issue_date = datetime.now().strftime("%Y-%m-%d")
            due_date = (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d")

            cursor.execute("UPDATE books SET available_copies=?, status=?, issue_date=?, due_date=? WHERE id=?", 
                           (new_avail, status, issue_date, due_date, self.selected_book_id))
            conn.commit()
            messagebox.showinfo("Success", f"{issue_qty} copy/copies issued successfully!\nDue Date: {due_date}")

        conn.close()
        self.refresh_table()

    def return_book(self):
        if not self.selected_book_id:
            messagebox.showwarning("Selection Error", "Please select a book.")
            return

        conn = sqlite3.connect('library_gui_v4.db')
        cursor = conn.cursor()
        cursor.execute("SELECT total_copies, available_copies, due_date FROM books WHERE id=?", (self.selected_book_id,))
        total, available, due_date_str = cursor.fetchone()

        issued_out = total - available

        if issued_out <= 0:
            messagebox.showinfo("Notice", "All copies of this book are already in the library.")
            conn.close()
            return

        return_qty = simpledialog.askinteger("Return Book", f"Copies Currently Issued: {issued_out}\n\nHow many copies are you returning?", minvalue=1, maxvalue=issued_out)

        if return_qty:
            new_avail = available + return_qty
            
            fine = 0.0
            days_late = 0
            if due_date_str and due_date_str != '-':
                due_date = datetime.strptime(due_date_str, "%Y-%m-%d")
                return_date = datetime.now()
                
                if return_date > due_date:
                    days_late = (return_date - due_date).days
                    fine = days_late * 2.0 * return_qty 

            if new_avail == total:
                cursor.execute("UPDATE books SET available_copies=?, status='Available', issue_date=NULL, due_date=NULL WHERE id=?", 
                               (new_avail, self.selected_book_id))
            else:
                cursor.execute("UPDATE books SET available_copies=?, status='Available' WHERE id=?", 
                               (new_avail, self.selected_book_id))
            
            conn.commit()
            
            if fine > 0:
                messagebox.showinfo("Book Returned", f"{return_qty} copy/copies returned late.\nDays Late: {days_late}\nTotal Fine: Rs. {fine}")
            else:
                messagebox.showinfo("Success", f"{return_qty} copy/copies returned successfully with no fine!")

        conn.close()
        self.refresh_table()

    def delete_book(self):
        if not self.selected_book_id:
            messagebox.showwarning("Selection Error", "Please select a book.")
            return
            
        confirm = messagebox.askyesno("Confirm Delete", "Are you sure you want to permanently delete this book?")
        if confirm:
            conn = sqlite3.connect('library_gui_v4.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM books WHERE id=?", (self.selected_book_id,))
            conn.commit()
            conn.close()
            self.refresh_table()

if __name__ == "__main__":
    root = tk.Tk()
    app = LibraryGUI(root)
    root.mainloop()