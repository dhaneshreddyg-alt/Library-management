import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

# --- Database Setup ---
def setup_database():
    conn = sqlite3.connect('library_gui.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS books (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        author TEXT NOT NULL,
                        status TEXT DEFAULT 'Available')''')
    conn.commit()
    conn.close()

# --- Main GUI Application ---
class LibraryGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Library Management System")
        self.root.geometry("1000x600")
        self.root.configure(bg="#f5f3ee")

        # Set up styles to mimic the HTML colors
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#f5f3ee")
        style.configure("Card.TFrame", background="#ffffff", relief="solid", borderwidth=1)
        style.configure("TLabel", background="#ffffff", font=("Arial", 10))
        style.configure("Header.TLabel", background="#1a237e", foreground="#ffffff", font=("Arial", 16, "bold"))
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"), background="#1a237e", foreground="white")
        
        setup_database()
        self.selected_book_id = None

        self.create_widgets()
        self.refresh_table()

    def create_widgets(self):
        # --- Header ---
        header_frame = tk.Frame(self.root, bg="#1a237e", height=60)
        header_frame.pack(fill="x", side="top")
        header_frame.pack_propagate(False)
        tk.Label(header_frame, text="📚 Library Management System", font=("Arial", 18, "bold"), bg="#1a237e", fg="white").pack(side="left", padx=20, pady=15)

        # --- Main Layout ---
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill="both", expand=True)

        # --- Left Panel ---
        left_panel = ttk.Frame(main_frame, width=250)
        left_panel.pack(side="left", fill="y", padx=(0, 20))

        # Add Book Card
        add_card = tk.Frame(left_panel, bg="#ffffff", bd=1, relief="solid", padx=15, pady=15)
        add_card.pack(fill="x", pady=(0, 20))
        tk.Label(add_card, text="➕ Add New Book", font=("Arial", 12, "bold"), bg="#ffffff", fg="#1a237e").pack(anchor="w", pady=(0, 10))
        
        tk.Label(add_card, text="TITLE", font=("Arial", 8, "bold"), bg="#ffffff", fg="#78716c").pack(anchor="w")
        self.title_entry = ttk.Entry(add_card)
        self.title_entry.pack(fill="x", pady=(0, 10))

        tk.Label(add_card, text="AUTHOR", font=("Arial", 8, "bold"), bg="#ffffff", fg="#78716c").pack(anchor="w")
        self.author_entry = ttk.Entry(add_card)
        self.author_entry.pack(fill="x", pady=(0, 15))

        add_btn = tk.Button(add_card, text="➕ Add Book", bg="#2e7d32", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.add_book)
        add_btn.pack(fill="x", ipady=5)

        # Actions Card
        action_card = tk.Frame(left_panel, bg="#ffffff", bd=1, relief="solid", padx=15, pady=15)
        action_card.pack(fill="x")
        tk.Label(action_card, text="⚙️ Book Actions", font=("Arial", 12, "bold"), bg="#ffffff", fg="#1a237e").pack(anchor="w", pady=(0, 10))
        tk.Label(action_card, text="Select a row in the table first.", font=("Arial", 8), bg="#ffffff", fg="#78716c").pack(anchor="w", pady=(0, 10))

        tk.Button(action_card, text="📤 Issue Book", bg="#e65100", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.issue_book).pack(fill="x", pady=5, ipady=3)
        tk.Button(action_card, text="📥 Return Book", bg="#1565c0", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.return_book).pack(fill="x", pady=5, ipady=3)
        tk.Frame(action_card, height=1, bg="#e2ddd6").pack(fill="x", pady=10) # Divider
        tk.Button(action_card, text="🗑️ Delete Book", bg="#b71c1c", fg="white", font=("Arial", 10, "bold"), relief="flat", command=self.delete_book).pack(fill="x", pady=5, ipady=3)

        # --- Right Panel ---
        right_panel = ttk.Frame(main_frame)
        right_panel.pack(side="left", fill="both", expand=True)

        # Search Bar
        search_frame = tk.Frame(right_panel, bg="#ffffff", bd=1, relief="solid", padx=10, pady=10)
        search_frame.pack(fill="x", pady=(0, 15))
        tk.Label(search_frame, text="🔍", bg="#ffffff", font=("Arial", 12)).pack(side="left", padx=(0, 5))
        self.search_entry = ttk.Entry(search_frame)
        self.search_entry.pack(side="left", fill="x", expand=True)
        self.search_entry.bind("<KeyRelease>", self.search_books)

        # Table Card
        table_frame = tk.Frame(right_panel, bg="#ffffff", bd=1, relief="solid")
        table_frame.pack(fill="both", expand=True)
        
        # Treeview (The Table)
        columns = ("id", "title", "author", "status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("id", text="ID")
        self.tree.heading("title", text="Title")
        self.tree.heading("author", text="Author")
        self.tree.heading("status", text="Status")
        
        self.tree.column("id", width=50, anchor="center")
        self.tree.column("title", width=250)
        self.tree.column("author", width=200)
        self.tree.column("status", width=100, anchor="center")
        
        self.tree.pack(fill="both", expand=True, padx=1, pady=1)
        self.tree.bind("<ButtonRelease-1>", self.select_row)

    # --- Database & UI Logic ---
    def refresh_table(self, search_query=""):
        for row in self.tree.get_children():
            self.tree.delete(row)
            
        conn = sqlite3.connect('library_gui.db')
        cursor = conn.cursor()
        
        if search_query:
            cursor.execute("SELECT * FROM books WHERE title LIKE ? OR author LIKE ?", ('%'+search_query+'%', '%'+search_query+'%'))
        else:
            cursor.execute("SELECT * FROM books")
            
        rows = cursor.fetchall()
        for row in rows:
            self.tree.insert("", "end", values=row)
            
        conn.close()
        self.selected_book_id = None

    def search_books(self, event):
        query = self.search_entry.get()
        self.refresh_table(query)

    def select_row(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item, 'values')
            self.selected_book_id = values[0]

    def add_book(self):
        title = self.title_entry.get().strip()
        author = self.author_entry.get().strip()
        
        if not title or not author:
            messagebox.showwarning("Input Error", "Please fill in both Title and Author.")
            return
            
        conn = sqlite3.connect('library_gui.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO books (title, author, status) VALUES (?, ?, 'Available')", (title, author))
        conn.commit()
        conn.close()
        
        self.title_entry.delete(0, tk.END)
        self.author_entry.delete(0, tk.END)
        self.refresh_table()

    def update_status(self, new_status, success_msg, error_msg):
        if not self.selected_book_id:
            messagebox.showwarning("Selection Error", "Please select a book from the table first.")
            return
            
        conn = sqlite3.connect('library_gui.db')
        cursor = conn.cursor()
        cursor.execute("SELECT status FROM books WHERE id=?", (self.selected_book_id,))
        current_status = cursor.fetchone()[0]
        
        if current_status == new_status:
            messagebox.showinfo("Notice", error_msg)
            conn.close()
            return
            
        cursor.execute("UPDATE books SET status=? WHERE id=?", (new_status, self.selected_book_id))
        conn.commit()
        conn.close()
        
        self.refresh_table()
        messagebox.showinfo("Success", success_msg)

    def issue_book(self):
        self.update_status('Issued', "Book issued successfully!", "This book is already issued.")

    def return_book(self):
        self.update_status('Available', "Book returned successfully!", "This book is already available.")

    def delete_book(self):
        if not self.selected_book_id:
            messagebox.showwarning("Selection Error", "Please select a book from the table first.")
            return
            
        confirm = messagebox.askyesno("Confirm Delete", "Are you sure you want to permanently delete this book?")
        if confirm:
            conn = sqlite3.connect('library_gui.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM books WHERE id=?", (self.selected_book_id,))
            conn.commit()
            conn.close()
            self.refresh_table()

if __name__ == "__main__":
    root = tk.Tk()
    app = LibraryGUI(root)
    root.mainloop()